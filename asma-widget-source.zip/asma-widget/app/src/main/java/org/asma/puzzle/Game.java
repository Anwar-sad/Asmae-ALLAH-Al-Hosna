package org.asma.puzzle;
import java.util.Random;
public final class Game {
 public static final String[][] GROUPS={
 {"الرحمن","الرحيم","الملك","القدوس","السلام","المؤمن"},
 {"المهيمن","العزيز","الجبار","المتكبر","الخالق","البارئ"},
 {"المصور","الحكيم","الأول","الآخر","الظاهر","الباطن"},
 {"الحي","القيوم","العلي","العظيم","السميع","البصير"}};
 public int group=0, placed=2; public long epoch=1; public int[] order={2,3,4,5};
 public void shuffle(Random r){ placed=2; for(int i=0;i<4;i++)order[i]=i+2; for(int i=3;i>0;i--){int j=r.nextInt(i+1),t=order[i];order[i]=order[j];order[j]=t;} epoch++; }
 public boolean tap(int name,long seen){ if(seen!=epoch||placed>=6||name!=placed)return false; placed++;epoch++;return true; }
 public boolean reshuffle(long seen,Random r){if(seen!=epoch)return false;shuffle(r);return true;}
 public String name(int n){return GROUPS[group][n];}
 public boolean visible(int n){return n>=placed&&n<6;}
}
