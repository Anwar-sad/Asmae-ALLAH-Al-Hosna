#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_HOME:-$PWD/tools/sdk}"
BT="$SDK/build-tools/35.0.0"
JAR="$SDK/platforms/android-35/android.jar"
mkdir -p tools build/compiled build/generated build/classes build/dex
"$BT/aapt2" compile --dir app/src/main/res -o build/compiled/resources.zip
sed 's/<manifest /<manifest package="org.asma.puzzle" /' app/src/main/AndroidManifest.xml >build/AndroidManifest.xml
"$BT/aapt2" link -o build/base.apk -I "$JAR" --manifest build/AndroidManifest.xml --java build/generated build/compiled/resources.zip
find app/src/main/java build/generated -name '*.java' >build/sources.txt
javac -encoding UTF-8 --release 8 -classpath "$JAR" -d build/classes @build/sources.txt
find build/classes -name '*.class' >build/classes.txt
"$BT/d8" --min-api 26 --lib "$JAR" --output build/dex @build/classes.txt
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f tools/test-signing.jks ]; then keytool -genkeypair -keystore tools/test-signing.jks -storepass android -keypass android -alias androiddebugkey -dname 'CN=Asma Widget Test' -keyalg RSA -keysize 2048 -validity 3650; fi
"$BT/apksigner" sign --ks tools/test-signing.jks --ks-pass pass:android --out build/asma-widget.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/asma-widget.apk
