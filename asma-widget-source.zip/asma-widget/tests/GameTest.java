package org.asma.puzzle;
import java.util.*;
public final class GameTest {
 static int checks;static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 public static void main(String[] args){Random r=new Random(77);Set<String> names=new HashSet<>();for(String[] group:Game.GROUPS)for(String n:group)check(names.add(n),"unique name");
 for(int run=0;run<10000;run++){Game a=new Game(),b=new Game();a.group=run%4;a.shuffle(r);long epoch=a.epoch;int[] sorted=a.order.clone();Arrays.sort(sorted);check(Arrays.equals(sorted,new int[]{2,3,4,5}),"complete shuffled pieces");check(a.placed==2,"two anchors");check(!a.tap(3,epoch),"wrong order unchanged");check(a.placed==2&&a.epoch==epoch,"wrong tap does not mutate");check(a.tap(2,epoch),"correct accepted");check(!a.tap(2,epoch),"double tap rejected");check(!a.tap(3,epoch),"old next rejected");long old=a.epoch;check(a.reshuffle(old,r),"shuffle");check(!a.tap(2,old),"tap after shuffle rejected");check(!a.reshuffle(old,r),"duplicate shuffle rejected");check(b.placed==2&&b.epoch==1,"other instance unchanged");for(int n=2;n<6;n++)check(a.tap(n,a.epoch),"ordered completion");check(a.placed==6,"completed");check(!a.tap(6,a.epoch),"beyond completion rejected");for(int n=2;n<6;n++)check(!a.visible(n),"placed pieces hidden");a.shuffle(r);check(a.placed==2,"restart");}
 System.out.println("PASS: "+checks+" assertions; 10000 shuffled sessions, ordering, repeated/stale taps, shuffle races, independent state, completion.");}
}
