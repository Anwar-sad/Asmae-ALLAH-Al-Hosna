# Validation report — 2026-11-24

## Executed
- Native Android resources compiled/linked with aapt2 35.0.0, Java compiled with JDK 21 targeting Java 8, dex produced by D8, APK zip-aligned and signed.
- apksigner verified v2/v3 signatures. Minimum API 26, target API 35.
- GameTest: 220,024 assertions over 10,000 randomized sessions passed. Covers exact four-piece permutation, fixed two-name anchors, wrong-order rejection, repeated tap rejection, stale events after a correct tap, stale taps after shuffle, repeated shuffle rejection, independent in-memory game instances, completion, hidden placed pieces, restart, and unique names.
- Source/manifest inspection: explicit RTL rows, independent persistence keys per widget ID, unique PendingIntent URI with widget ID and state epoch, immutable PendingIntents, no requested permissions, no background service, no network permission, no periodic update schedule.
- Delayed highlight clear checks current state epoch and widget existence; cannot overwrite a newer shuffle or another widget's state.

## Not executed / limitations
- No physical Android phone connected. An official Android 11 x86_64 emulator was provisioned; the cloud host lacks /dev/kvm. Software emulation was attempted, but no successful Android boot, APK installation or launcher interaction was observed before execution transport became unavailable. A second runtime could not reuse the running emulator. Reconnected to recover outputs.
- Therefore actual tap dispatch, rapid tapping through the launcher, persisted multi-widget isolation, widget resize/rotation, font rendering/RTL visual layout, glow duration, sound behavior, add-widget flow and real screen sizing are NOT runtime-verified. Model tests are not substitutes for those tests.
- Art is a native programmatic adaptation of the supplied reference, not a verified pixel-perfect match. Small six-slot labels need phone inspection. Name labels are bitmaps with accessibility descriptions; they do not scale independently with system font-size settings.
- Completion leaves names visible until manual shuffle. The first two names remain fixed guides in every round. Includes 24 names, not a complete 99-name curriculum.
- The APK is a signed experimental build, not a production release.

## Required phone acceptance checks
1. Install on Android 8+; add two widgets to a launcher, initially at roughly full width / 4×5 cells.
2. Confirm Arabic joins correctly; six slots run right-to-left, shuffle is top-left, four loose pieces are large, no phone image or quiz is present.
3. Choose different groups in the two widgets. Solve one, verify the other is unchanged; restart launcher and verify each persists.
4. Tap wrong piece, then correct; rapid double-tap correct piece; tap a piece immediately around shuffle. No duplication or advancement from a stale event should occur.
5. Complete and shuffle, including during the brief highlight. Verify no old delayed render restores previous state.
6. Resize down/up and rotate; verify no clipping and comfortable touch targets. Test large system fonts and TalkBack. Check long names in all groups.
7. Sound off/on, normal/silent/DND, system touch sounds off; verify no music or unwanted audio. Actual system sound can vary by device.
8. Leave/reopen home: progress should remain; automatic home-return shuffle is intentionally unsupported.
9. Delete one instance and re-add; verify other remains intact. Force-stop/relaunch and reboot; check recovery. Do not infer success until checked.
