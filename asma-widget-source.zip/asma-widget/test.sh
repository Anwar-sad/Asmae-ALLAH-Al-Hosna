#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/tests
javac --release 8 -d build/tests app/src/main/java/org/asma/puzzle/Game.java tests/GameTest.java
java -cp build/tests org.asma.puzzle.GameTest
