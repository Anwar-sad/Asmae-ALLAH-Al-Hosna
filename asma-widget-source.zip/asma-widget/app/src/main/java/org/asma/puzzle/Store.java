package org.asma.puzzle;
import android.content.*;import java.util.Random;
final class Store {
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("puzzles",0);}
 static Game load(Context c,int id){android.content.SharedPreferences p=prefs(c);String k=id+".";Game g=new Game(); if(!p.contains(k+"epoch")){g.shuffle(new Random());save(c,id,g);return g;}g.group=p.getInt(k+"group",0);g.placed=p.getInt(k+"placed",2);g.epoch=p.getLong(k+"epoch",1);for(int i=0;i<4;i++)g.order[i]=p.getInt(k+"o"+i,i+2);return g;}
 static void save(Context c,int id,Game g){String k=id+".";android.content.SharedPreferences.Editor e=prefs(c).edit().putInt(k+"group",g.group).putInt(k+"placed",g.placed).putLong(k+"epoch",g.epoch);for(int i=0;i<4;i++)e.putInt(k+"o"+i,g.order[i]);e.commit();}
 static void delete(Context c,int id){android.content.SharedPreferences.Editor e=prefs(c).edit();for(String k:prefs(c).getAll().keySet())if(k.startsWith(id+"."))e.remove(k);e.commit();}
}
